export const BENIS = {};

/**
 * The set of Ability Scores used within the system.
 * @type {Object}
 */
BENIS.abilities = {
  agi: 'BENIS.Ability.Agi.long',
  bra: 'BENIS.Ability.Bra.long',
  fel: 'BENIS.Ability.Fel.long',
  int: 'BENIS.Ability.Int.long',
  per: 'BENIS.Ability.Per.long',
  wil: 'BENIS.Ability.Wil.long',
};

BENIS.abilityAbbreviations = {
  agi: 'BENIS.Ability.Agi.abbr',
  bra: 'BENIS.Ability.Bra.abbr',
  fel: 'BENIS.Ability.Fel.abbr',
  int: 'BENIS.Ability.Int.abbr',
  per: 'BENIS.Ability.Per.abbr',
  wil: 'BENIS.Ability.Wil.abbr',
};

BENIS.skills = {
  action: 'BENIS.Skill.Action',
  creation: 'BENIS.Skill.Creation',
  darkness: 'BENIS.Skill.Darkness',
  immanence: 'BENIS.Skill.Immanence',
  luminance: 'BENIS.Skill.Luminance',
  potency: 'BENIS.Skill.Potency',
  resolve: 'BENIS.Skill.Resolve',
  traversal: 'BENIS.Skill.Traversal',
  unity: 'BENIS.Skill.Unity',
  vitality: 'BENIS.Skill.Vitality',
};
